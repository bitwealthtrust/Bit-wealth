# Bit-Wealth — Stage 1
Core UI and database schema foundation.

## Run
npm install
npm run dev

Routes:
/
/login
/register
/dashboard
/admin

The schema in `db/schema.sql` defines users, investments and transactions. The pages are intentionally not connected to real money movement yet.

Before production: implement server-side authentication, secure sessions, authorization, validation, CSRF protection, rate limiting, encrypted secrets, audit logs, backups, KYC/AML and applicable financial regulations.